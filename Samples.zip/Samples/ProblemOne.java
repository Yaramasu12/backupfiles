/**
 * 
 */
package Samples;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

/**
 * @author s545622(Chaitanya Swaroop Udata)
 *
 */
public class ProblemOne {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter the Elements: ");
		Scanner sc = new Scanner(System.in);
		ArrayList<Integer> l1= new ArrayList<>();
		
		for(int i=0;i<7;i++) {
			int ele = sc.nextInt();
			l1.add(ele);
		}
		
		LinkedList<Integer> res = extractPrimeNumber(l1);
		System.out.println(res);
	}
	
	public static LinkedList<Integer> extractPrimeNumber(ArrayList<Integer> input)
	{
		LinkedList<Integer> res= new LinkedList<>();
		for(int i=0;i<input.size();i++) {
			if(isPrime(input.get(i))) {
				res.add(input.get(i));
			}
		}
		
		return res;


	}
	
	private static boolean isPrime(int n)
    {
        // Corner case
        if (n <= 1)
            return false;
  
        // Check from 2 to n-1
        for (int i = 2; i < n; i++)
            if (n % i == 0)
                return false;
  
        return true;
    }
}
