package designs;

import java.util.Scanner;

public class FactoryMethodDriver {

	public static void main(String[] args) {
		try (Scanner scan = new Scanner(System.in)) {
			PeopleFactory people = new PeopleFactory();
			System.out.println("Enter the people: ");
			String peopl = scan.next();
			People ent = people.getPeople(peopl);

			if (ent instanceof Student) {
				Student s = (Student) ent;
				System.out.println("Enter the value of side of the square: ");
				double side = scan.nextDouble();
				s.setprice(side); 
				System.out.print("food: " ); s.buyFood();
				System.out.println("book: " + s.buyBook());
			}
			else if(ent instanceof Staff) {
				Staff r = (Staff) ent;
				System.out.println("Enter price of the staff: ");
				
				r.setPrice(scan.nextDouble());
				System.out.println("book: " + r.buyBook());
				System.out.print("food: ");r.buyFood();				
			}
			else if(ent instanceof Faculty) {
				Faculty c = (Faculty) ent;
				System.out.println("Enter the radius of circle: ");
				c.setPrice(scan.nextDouble());
				System.out.println("book: " + c.buyBook());
				System.out.println("food: "); c.buyFood();					
			}
			else {
				System.out.println("Not a correct shape!");
			}
		}

	}

}
