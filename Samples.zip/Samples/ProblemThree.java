/**
 * 
 */
package Samples;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;
import java.util.Stack;

/**
 * @author s545622(Chaitanya Swaroop Udata)
 *
 */
public class ProblemThree {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter the Elements: ");
		Scanner sc = new Scanner(System.in);
		Stack<Integer> stack = new Stack<>();
		for (int i = 0; i < 3; i++) {
			int no = sc.nextInt();
			stack.add(no);
		}

		displayStack(stack);
		return;
	}

	public static void displayStack(Stack<Integer> input) {
		while (!input.isEmpty()) {
			int ele = input.pop();
			System.out.println(ele);
		}
		return;
	}
}
