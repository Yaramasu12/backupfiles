package designs;

public class Student implements People {
	private double price;

	public Student(double price) {
		this.price = price;
	}

	public Student() {
		super();
	}

	public double getprice() {
		return price;
	}

	public void setprice(double price) {
		this.price = price;
	}

	@Override
	public void buyFood() {		
		System.out.println(price);
	}

	@Override
	public double buyBook() {
		return 4*price;
	}

}
