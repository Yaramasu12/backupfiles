/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package employeeSalary;

/**
 * @author Sridevi Yandapalli
 * @author S546764
 */
public class EmployeeSalary {
    private double hourlyRate;
  private double insuranceRate;
  private double taxRate;
  private double pfRate;
  private int hours = 40;
  /** Creates a Employee with required parameters.
   * @param hourlyRate Hourly pay rate of the employee
   * @param insuranceRate Insurance percentage
   * @param taxRate Tax percentage
   * @param pfRate pf percentage
   */
  public EmployeeSalary(double hourlyRate,double insuranceRate,double taxRate,double pfRate){
  this.hourlyRate=hourlyRate;
  this.insuranceRate=insuranceRate;
  this.taxRate=taxRate;
  this.pfRate=pfRate;
  }
  /** Creates a EmployeeSalary with initial values(default values).
   */
  public EmployeeSalary(){
  }
  /** Gets the HourlyRate.
   * @return A double value representing the HourlyRate.
   */
  public double getHourlyRate(){
      return hourlyRate;
  }
  /** Gets the InsuranceRate.
   * @return A double value representing the InsuranceRate.
   */
  public double getInsuranceRate(){
      return insuranceRate;
  }
  /** Gets the PfRate.
   * @return A double value representing the PfRate.
   */
  public double getPfRate(){
      return pfRate;
  }
  /** Gets the Hours.
   * @return A integer value representing the HourlyRate.
   */
  public int getHours(){
      return hours;
  }
  /** Sets the HourlyRate.
   * @param hourlyRate Hourly pay rate of the Employee
   */
  public void setHourlyRate(double hourlyRate){
      this.hourlyRate=hourlyRate;
  }
  /** Sets the InsuranceRate.
   * @param InsuranceRate Insurance percentage
   */
  public void setInsuranceRate(double InsuranceRate){
      this.insuranceRate=InsuranceRate;
  }
  /** Sets the PfRate.
   * @param PfRate Pf percentage
   */
  public void setPfRate(double PfRate){
      this.pfRate=PfRate;
  }
  /** Sets the TaxRate.
   * @param taxRate Tax Percentage
   */
  public void setTaxRate(double taxRate){
      this.taxRate = taxRate;
  }
  /** Sets the Hours.
   * @param hours Total hours of work per week,initialize with 40
   */
  public void setHours(int hours){
      this.hours=hours;
  }
  public double calcMonthlySalary(){
      return(hours*4*hourlyRate);
  }
  public double calcMonthlyInsurance(){
      return(calcMonthlySalary()*insuranceRate)/100;
  }
  public double calcMonthlyPfAmount(){
      return(calcMonthlySalary()*pfRate)/100;
  }
  public double calcAnnualGrossSalary(double bonus){
      return calcMonthlySalary()*12+bonus;
  }
  public double calcAnnualNetPay(double bonus){
      return calcAnnualGrossSalary(bonus)-(calcAnnualGrossSalary(bonus)*taxRate/100)-12*calcMonthlyInsurance()-12*calcMonthlyPfAmount();
  }
  @Override
  public String toString(){
      return "hourlyRate: "+hourlyRate+", insuranceRate: "+insuranceRate+", taxRate:"+taxRate+", pfRate: "+pfRate+", HOURS: "+hours;
    }
}
