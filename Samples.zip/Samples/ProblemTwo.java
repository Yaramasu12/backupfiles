package Samples;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

/**
 * @author s545622(Chaitanya Swaroop Udata)
 *
 */

public class ProblemTwo {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter the Elements: ");
		Scanner sc = new Scanner(System.in);
		ArrayList<Integer>l1= new ArrayList<Integer>();
		for(int i=0;i<7;i++) {
			int ele = sc.nextInt();
			l1.add(ele);
		}
		ArrayList<Integer> res = distinctNumber(l1);
		System.out.println(res);
	}
	
	public static ArrayList<Integer> distinctNumber (ArrayList<Integer> input)
	{
		ArrayList<Integer> res= new ArrayList<>();
		HashSet<Integer> set = new HashSet<>();
		for(int i=0;i<input.size();i++) {
			if(!set.contains(input.get(i))) {
				res.add(input.get(i));
				set.add(input.get(i));
			}
		}
		return res;


	}
}
