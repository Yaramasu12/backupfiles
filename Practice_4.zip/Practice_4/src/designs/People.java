package designs;

public interface People{
	public void buyFood();
	public double buyBook();
}
