/**
 * 
 */
package Samples;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Deque;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;
import java.util.Stack;

/**
 * @author s545622(Chaitanya Swaroop Udata)
 *
 */
public class ProblemFive {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter the Elements: ");
		Scanner sc = new Scanner(System.in);
		Deque<Integer> input = new ArrayDeque<Integer>();
		for (int i = 0; i < 7; i++) {
			int ele = sc.nextInt();
			input.add(ele);
		}
		int res = computeFirstLast(input);
		System.out.println(res);
	}

	public static int computeFirstLast(Deque<Integer> input) {
		int first = input.getFirst();
		int last = input.getLast();
		return first + last;

	}
}
