/**
 * 
 */
package Samples;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Scanner;
import java.util.Stack;

/**
 * @author s545622(Chaitanya Swaroop Udata)
 *
 */
public class ProblemSeven {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter the Elements: ");
		Scanner sc = new Scanner(System.in);
		Map<Integer,String> input= new HashMap<Integer,String>();
		input.put(1,"one");
		input.put(2, "two");
		input.put(3, "three");
		

		Map<Integer,String> output = resetMap(input);
		System.out.println(output);
	}
	
	public static Map<Integer,String> resetMap(Map<Integer,String> input)
	{
		Map<Integer,String> output = new HashMap<>();
		for(Map.Entry<Integer, String> entry:input.entrySet()) {
			int key = entry.getKey();
			String value = "Done";
			output.put(key, value);
		}
		return output;
	}
}
