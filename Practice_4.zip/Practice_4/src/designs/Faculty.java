package designs;

public class Faculty implements People {
	private double price;

	public Faculty(double price) {
		this.price = price;
	}

	public Faculty() {
		super();
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	@Override
	public void buyFood() {		
		System.out.println(price+2.9);
	}

	@Override
	public double buyBook() {
		return 4*price;
	}

}
