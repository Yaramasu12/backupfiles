/**
 * 
 */
package Samples;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Scanner;
import java.util.Stack;

/**
 * @author s545622(Chaitanya Swaroop Udata)
 *
 */
public class ProblemFour {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter the Elements: ");
		Scanner sc = new Scanner(System.in);
		Queue<Integer> l1 = new LinkedList<>();
		for (int i = 0; i < 7; i++) {
			int ele = sc.nextInt();
			l1.add(ele);
		}

		displayQueue(l1);
		return;
	}

	public static void displayQueue(Queue<Integer> q) {
		Stack<Integer> stack = new Stack<>();
		while (!q.isEmpty()) {
			int ele = q.remove();
			stack.add(ele);
		}

		while (!stack.isEmpty()) {
			int ele = stack.pop();
			System.out.println(ele);
		}
	}
}
