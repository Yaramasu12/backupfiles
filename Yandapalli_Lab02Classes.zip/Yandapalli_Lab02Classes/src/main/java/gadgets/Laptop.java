/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gadgets;

/**
 * @author Sridevi Yandapalli
 * @author S546764
 */
public class Laptop {
    private String laptopBrand;
  private String processor;
  private double display ;
  private int hardDrive ;
  private String operatingSystem;
  private boolean touch;

    /**
     * Create a Laptop with given parameters
     * @param laptopBrand Laptop Brand name like HP/Dell
     * @param processor Name of the processor
     * @param operatingSystem Screen size in inches
     * @param hardDrive Memory size in GB’s
     * @param display OS name like Windows/Linux
     * @param touch Is supported touch screen or not.
     */
    public Laptop(String laptopBrand, String processor,String operatingSystem, int hardDrive,double display, boolean touch) {
        this.laptopBrand = laptopBrand;
        this.processor = processor;
        this.display = display;
        this.hardDrive = hardDrive;
        this.operatingSystem = operatingSystem;
        this.touch = touch;
    }

    /**
     * Creating a constructor with no arguments
     */
    public Laptop() {
    }

    /**
     * Creating a get method for LaptopBrand
     * @return LaptopBrand
     */
    public String getLaptopBrand() {
        return laptopBrand;
    }

    /**
     * Creating a set method for LaptopBrand
     * @param laptopBrand name of the laptop brand
     */
    public void setLaptopBrand(String laptopBrand) {
        this.laptopBrand = laptopBrand;
    }

    /**
     * Creating a get method for processor
     * @return processor
     */
    public String getProcessor() {
        return processor;
    }

    /**
     * creating a set method for Processor
     * @param processor Name of the processor
     */
    public void setProcessor(String processor) {
        this.processor = processor;
    }

    /**
     * Creating a get method for Display
     * @return display
     */
    public double getDisplay() {
        return display;
    }

    /**
     * Creating a set method for display
     * @param display name of the display
     */
    public void setDisplay(double display) {
        this.display = display;
    }

    /**
     * Creating a get method for HardDrive
     * @return HardDrive
     */
    public int getHardDrive() {
        return hardDrive;
    }

    /**
     * Creating a set method for HardDrive
     * @param hardDrive name of the HardDrive
     */
    public void setHardDrive(int hardDrive) {
        this.hardDrive = hardDrive;
    }

    /**
     * Creating a get method for OperatingSystem
     * @return OperatingSystem
     */
    public String getOperatingSystem() {
        return operatingSystem;
    }

    /**
     * Creating a set method for OperatingSystem
     * @param operatingSystem Name of the operatingSystem
     */
    public void setOperatingSystem(String operatingSystem) {
        this.operatingSystem = operatingSystem;
    }

    /**
     * Creating a get method of Boolean for Touch
     * @return touch
     */
    public boolean isTouch() {
        return touch;
    }

    /**
     * Creating a set method for Touch
     * @param touch Touch supported or not
     */
    public void setTouch(boolean touch) {
        this.touch = touch;
    }

    @Override
    public String toString() {
        return  "Laptop Brand: " + laptopBrand + "\nLaptop Processor: " + processor + "\nLaptop Operating System: " + operatingSystem+ "\nLaptop Hard Drive: " + hardDrive  +"\nLaptop Display: " + display  + "\nLaptop Is Touch: " + touch ;
        
    }
}
