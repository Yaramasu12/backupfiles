/**
 * 
 */
package Samples;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Deque;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;
import java.util.Stack;

/**
 * @author s545622(Chaitanya Swaroop Udata)
 *
 */
public class ProblemSix {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter the Elements: ");
		Scanner sc = new Scanner(System.in);
		Deque<Integer> input =new ArrayDeque<Integer>();
		for(int i=0;i<7;i++) {
			int ele = sc.nextInt();
			input.add(ele);
		}
		int res =  sumMaxMin(input);
		System.out.println(res);
	}
	
	public static int sumMaxMin (Deque<Integer> input)
	{
		int max=Integer.MIN_VALUE;
		int min=Integer.MAX_VALUE;
		while(!input.isEmpty()) {
			int ele = input.poll();
			min = Math.min(min,ele);
			max = Math.max(max, ele);
		}
		
		return min+max;

	}
}
