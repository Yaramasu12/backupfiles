package designs;

public class Staff implements People{
	private double price;

	public Staff(double price) {
		this.price = price;
	}

	public Staff() {
		super();
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	@Override
	public double buyBook() {		
		return price*price;
	}

	@Override
	public void buyFood() {
		System.out.println(price*2.8);
	}

}
