/**
 * 
 */
package Samples;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Deque;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Scanner;
import java.util.Stack;

/**
 * @author s545622(Chaitanya Swaroop Udata)
 *
 */
public class ProblemTen {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter the Elements: ");
		Scanner sc = new Scanner(System.in);
		ArrayList<Integer> q = new ArrayList<>();
		for (int i = 0; i < 5; i++) {
			int ele = sc.nextInt();
			q.add(ele);
		}

		ArrayList<Integer> a = new ArrayList<>();
		for (int i = 0; i < 5; i++) {
			int ele = sc.nextInt();
			a.add(ele);
		}

		sumIndices(q, a);
		return;
	}

	public static void sumIndices(ArrayList<Integer> l1, ArrayList<Integer> l2) {
		for (int i = 0; i < l2.size(); i++) {
			int ele = l2.get(i);
			int firstIndex = getFirstOccurence(ele, l1);
			int lastIndex = getLastOccurence(ele, l1);

			int sum = firstIndex + lastIndex;
			System.out.println(sum);

		}
		return;
	}

	private static int getFirstOccurence(int ele, ArrayList<Integer> input) {
		for (int i = 0; i < input.size(); i++) {
			if (input.get(i) == ele) {
				return i;
			}
		}
		return -1;
	}

	private static int getLastOccurence(int ele, ArrayList<Integer> input) {
		for (int i = input.size() - 1; i >= 0; i--) {
			if (input.get(i) == ele) {
				return i;
			}
		}
		return -1;
	}
}
