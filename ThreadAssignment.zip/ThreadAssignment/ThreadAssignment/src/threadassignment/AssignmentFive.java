/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package threadassignment;
/**
 *
 * @author S545499
 */
public class AssignmentFive {
    public static void main(String[] args) throws InterruptedException {
		Wallmart Wall=new Wallmart();
		Cashier Cashi=new Cashier(Wall,"bapaiah");
		Cashier Cash=new Cashier(Wall,"Sridevi");
		Thread thr1=new Thread(Cashi);
		Thread thr2=new Thread(Cash);
		thr1.start();		
		thr2.start();	
	}
}
