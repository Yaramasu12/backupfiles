/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package threadassignment;

/**
 *
 * @author S545499
 */
public class Wallmart {
    int count;
    double total;
    
public Wallmart() {
    this.total=0.0;
}
public void totalPrice(String itemname[],double priceamount[]) throws InterruptedException{
	double newTotal = 0;
        int n=0;
	while(n<itemname.length) {
	newTotal = newTotal+priceamount[n];
	count++;
	n++;
      }	
        total=newTotal;
    }
}
