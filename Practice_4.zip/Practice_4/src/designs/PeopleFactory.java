package designs;

public class PeopleFactory {
	public People getPeople(String people) {
		if(people.equalsIgnoreCase("Student")){
			return new Student();
		}
		else if(people.equalsIgnoreCase("Faculty")) {
			return new Faculty();
		}
		else if(people.equalsIgnoreCase("Staff")){
			return new Staff();
		}
		else{
			return null;
		}
	}

}
