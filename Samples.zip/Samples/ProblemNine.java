/**
 * 
 */
package Samples;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Deque;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Scanner;
import java.util.Stack;

/**
 * @author s545622(Chaitanya Swaroop Udata)
 *
 */
public class ProblemNine {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter the Elements: ");
		Scanner sc = new Scanner(System.in);
		ArrayList<Integer> q = new ArrayList<>();
		for (int i = 0; i < 4; i++) {
			int ele = sc.nextInt();
			q.add(ele);
		}
		ArrayList<Integer> l = distinctList(q);
		System.out.println(l);
	}

	public static ArrayList<Integer> distinctList(ArrayList<Integer> input) {
		ArrayList<Integer> res = new ArrayList<>();
		for (int i = 0; i < input.size(); i++) {
			int ele = input.get(i);
			int lastIndex = getLastOccurence(ele, input);
			if (lastIndex == i) {
				res.add(ele);
			}
		}
		return res;
	}

	private static int getLastOccurence(int ele, ArrayList<Integer> input) {
		for (int i = input.size() - 1; i >= 0; i--) {
			if (input.get(i) == ele) {
				return i;
			}
		}
		return -1;
	}
}
