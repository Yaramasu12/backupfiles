/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package threadassignment;
import java.util.Scanner;

/**
 *
 * @author S545499
 */
public class Cashier implements Runnable{
	String name;
        Wallmart objWallmart;
	public Cashier(Wallmart objWallmart,String name) {
		this.name=name;
		this.objWallmart=objWallmart;
	}
	@Override
	public void run() {
		synchronized(objWallmart) {
		Scanner keyboar=new Scanner(System.in);
		System.out.println("Enter No of Items in Walmart ");
		int pri=keyboar.nextInt();
		String itemname[]=new String[pri];
		double pricename[]=new double[pri];		
		for(int z=0;z<pri;z++) {
			System.out.println("Enter the item no for "+(z+1));
			itemname[z]=keyboar.next();
			System.out.println("Enter the price for the item no of "+(z+1));
			pricename[z]=keyboar.nextInt();} 		
		try {
			objWallmart.totalPrice(itemname, pricename);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println(objWallmart.total+"**"+objWallmart.count);	
	}
    }
}
